package com.yunmeng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HouseMasterManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(HouseMasterManagementApplication.class, args);
    }

}
