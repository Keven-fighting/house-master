package com.yunmeng.service;


import com.yunmeng.pojo.Message;
import com.yunmeng.pojo.PageBean;
import com.yunmeng.pojo.User;

// 管理员业务规则
public interface AdminService {
    void save(User user);

    void login(String username, String password, Integer admin);


    void deleteByUsername(String username);

    PageBean page(Integer page, Integer pageSize);

    void update(User user);

    void addMessage(Message message);

    PageBean pageMessage(String estateName,Integer page, Integer pageSize);


    void deleteMessage(String messagetitle, String messagename);


}
